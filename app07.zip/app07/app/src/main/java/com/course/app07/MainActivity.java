package com.course.app07;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView myRecyclerView;
    private RecyclerView.LayoutManager myLayoutManager;
    Button b1;
    Button b3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        myRecyclerView = (RecyclerView)
                findViewById(R.id.recyclerView);
        myRecyclerView.setHasFixedSize(true);
        myLayoutManager = new LinearLayoutManager(this);
        myRecyclerView.setLayoutManager(myLayoutManager);

        ArrayList<Schools.School> schoolsInfo = new ArrayList<>();
        schoolsInfo.add(new Schools.School(R.drawable.blumenlied, R.drawable.lange, "꽃노래",9000,"G.lange 가 작곡하였다."));
        schoolsInfo.add(new Schools.School(R.drawable.prayer,R.drawable.bada, "소녀의 기도",10500,"T.badarzewska 가 작곡하였다."));
        schoolsInfo.add(new Schools.School(R.drawable.nocturne,R.drawable.chopin ,"녹턴",10000,"F.chopin 가 작곡하였다."));
        schoolsInfo.add(new Schools.School(R.drawable.maybe,R.drawable.lee, "maybe",20000,"이루마 가 작곡하였다."));
        schoolsInfo.add(new Schools.School(R.drawable.way,R.drawable.kim, "학교가는 길",23000,"김광민 가 작곡하였다."));
        schoolsInfo.add(new Schools.School(R.drawable.paris, R.drawable.monla,"paris paris",18000,"Monla 가 작곡하였다."));
        schoolsInfo.add(new Schools.School(R.drawable.csikos, R.drawable.necke,"크시코스의 우편마차",19050,"Hermann necke 가 작곡하였다."));
        schoolsInfo.add(new Schools.School(R.drawable.heart,R.drawable.david, "return to heart",16000,"David lanz 가 작곡하였다."));
        schoolsInfo.add(new Schools.School(R.drawable.summer,R.drawable.joe, "summer",5500,"Hisaishi joe 가 작곡하였다."));
        schoolsInfo.add(new Schools.School(R.drawable.silvery,R.drawable.wyman, "은파",4800,"A.P.wyman 가 작곡하였다."));

        MyAdapter myAdapter = new MyAdapter(schoolsInfo);

        myRecyclerView.setAdapter(myAdapter);




        b1 = (Button)findViewById(R.id.button);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("tel:01026297955"));
                startActivity(intent);
            }
        });

        b3 = (Button)findViewById(R.id.button3);
        b3.setOnClickListener(new View.OnClickListener() {
                                  @Override
                                  public void onClick(View v) {
                                      Context context = v.getContext();
                                      Intent intent = new Intent(context, MapsActivity.class);
                                      context.startActivity(intent);
                                  }
                              });

        Button startBtn = (Button) findViewById(R.id.button2);
        startBtn.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view) {
                sendEmail();
            }
        });


    }
    protected void sendEmail() {
        String[] TO = {""};
        String[] CC = {""};
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setData(Uri.parse("mailto:"));
        emailIntent.setType("text/plain");
        emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
        emailIntent.putExtra(Intent.EXTRA_CC, CC);

        try {
            startActivity(Intent.createChooser(emailIntent, "이메일 보내기..."));

            finish();
        } catch (android.content.ActivityNotFoundException ex)
        {
            Toast.makeText(MainActivity.this, "이메일 클라이언트가 없네요.", Toast.LENGTH_SHORT).show();
        }
    }
}
