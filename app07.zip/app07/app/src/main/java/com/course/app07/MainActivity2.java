package com.course.app07;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    ImageView detailImage;
    ImageView detailImage2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Intent intent = getIntent();

        final String name = intent.getExtras().getString("name");

        String explanation = intent.getExtras().getString("explanation");

        int price = intent.getExtras().getInt("price");

        int imageResource = intent.getExtras().getInt("imageResource");

        int imageResource2 = intent.getExtras().getInt("imageResource2");


        detailImage = (ImageView)findViewById(R.id.imageView3);
        detailImage.setImageResource(imageResource);

        detailImage2 = (ImageView)findViewById(R.id.imageView4);
        detailImage2.setImageResource(imageResource2);

        TextView nameTextView = (TextView)findViewById(R.id.textView3);
        nameTextView.setText(name);

        TextView descriptionTextView = (TextView)findViewById(R.id.textView4);
        descriptionTextView.setText(explanation);

        TextView priceTextView = (TextView)findViewById(R.id.textView5);
        priceTextView.setText(price + "원");



    }
}