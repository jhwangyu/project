package com.course.app07;

public class Schools {
    String school_name;

    int image_id;

    String school_public;
        static class School {

            String school_name;
            int image_id;
            int image_id2;
            int price;
            String explanation;


            public School(int id, int id2, String name, int price, String explanation) {
                this.image_id = id;
                this.image_id2 =id2;
                this.school_name = name;
                this.price = price;
                this.explanation = explanation;


            }

            public String getSchoolName() {
                return school_name;
            }

            public int getImageID() {
                return image_id;
            }

            public int getImageID2(){return image_id2;}

            public String getExplanation(){return explanation;}

            public int getPrice(){return price;}


        }
}
